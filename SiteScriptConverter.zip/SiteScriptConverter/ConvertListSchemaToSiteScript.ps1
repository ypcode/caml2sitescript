param (
    [string]$ListSchemaXml,
    [string]$Output="site-script.json"
)

dotnet .\YPCode.CAML2SiteDesigns.CLI.dll convert-list-schema -s $ListSchemaXml -o $Output